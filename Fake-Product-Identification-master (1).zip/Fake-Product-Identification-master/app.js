// app.js
document.addEventListener('DOMContentLoaded', async () => {
    // Connect to the contract
    const contractAddress = '0xd8b934580fcE35a11B58C6D73aDeE468a2833fa8';
    const contractABI = [
        {
            "inputs": [
                {
                    "internalType": "bytes32",
                    "name": "_manufactuerID",
                    "type": "bytes32"
                },
                {
                    "internalType": "bytes32",
                    "name": "_productName",
                    "type": "bytes32"
                },
                {
                    "internalType": "bytes32",
                    "name": "_productSN",
                    "type": "bytes32"
                },
                {
                    "internalType": "bytes32",
                    "name": "_productBrand",
                    "type": "bytes32"
                },
                {
                    "internalType": "uint256",
                    "name": "_productPrice",
                    "type": "uint256"
                }
            ],
            "name": "addProduct",
            "outputs": [],
            "stateMutability": "nonpayable",
            "type": "function"
        },
        {
            "inputs": [
                {
                    "internalType": "bytes32",
                    "name": "_manufacturerId",
                    "type": "bytes32"
                },
                {
                    "internalType": "bytes32",
                    "name": "_sellerName",
                    "type": "bytes32"
                },
                {
                    "internalType": "bytes32",
                    "name": "_sellerBrand",
                    "type": "bytes32"
                },
                {
                    "internalType": "bytes32",
                    "name": "_sellerCode",
                    "type": "bytes32"
                },
                {
                    "internalType": "uint256",
                    "name": "_sellerNum",
                    "type": "uint256"
                },
                {
                    "internalType": "bytes32",
                    "name": "_sellerManager",
                    "type": "bytes32"
                },
                {
                    "internalType": "bytes32",
                    "name": "_sellerAddress",
                    "type": "bytes32"
                }
            ],
            "name": "addSeller",
            "outputs": [],
            "stateMutability": "nonpayable",
            "type": "function"
        },
        {
            "inputs": [
                {
                    "internalType": "bytes32",
                    "name": "_productSN",
                    "type": "bytes32"
                },
                {
                    "internalType": "bytes32",
                    "name": "_sellerCode",
                    "type": "bytes32"
                }
            ],
            "name": "manufacturerSellProduct",
            "outputs": [],
            "stateMutability": "nonpayable",
            "type": "function"
        },
        {
            "inputs": [
                {
                    "internalType": "bytes32",
                    "name": "_productSN",
                    "type": "bytes32"
                },
                {
                    "internalType": "bytes32",
                    "name": "_consumerCode",
                    "type": "bytes32"
                }
            ],
            "name": "sellerSellProduct",
            "outputs": [],
            "stateMutability": "nonpayable",
            "type": "function"
        },
        {
            "inputs": [
                {
                    "internalType": "bytes32",
                    "name": "_consumerCode",
                    "type": "bytes32"
                }
            ],
            "name": "getPurchaseHistory",
            "outputs": [
                {
                    "internalType": "bytes32[]",
                    "name": "",
                    "type": "bytes32[]"
                },
                {
                    "internalType": "bytes32[]",
                    "name": "",
                    "type": "bytes32[]"
                },
                {
                    "internalType": "bytes32[]",
                    "name": "",
                    "type": "bytes32[]"
                }
            ],
            "stateMutability": "view",
            "type": "function"
        },
        {
            "inputs": [
                {
                    "internalType": "uint256",
                    "name": "",
                    "type": "uint256"
                }
            ],
            "name": "productItems",
            "outputs": [
                {
                    "internalType": "uint256",
                    "name": "productId",
                    "type": "uint256"
                },
                {
                    "internalType": "bytes32",
                    "name": "productSN",
                    "type": "bytes32"
                },
                {
                    "internalType": "bytes32",
                    "name": "productName",
                    "type": "bytes32"
                },
                {
                    "internalType": "bytes32",
                    "name": "productBrand",
                    "type": "bytes32"
                },
                {
                    "internalType": "uint256",
                    "name": "productPrice",
                    "type": "uint256"
                },
                {
                    "internalType": "bytes32",
                    "name": "productStatus",
                    "type": "bytes32"
                }
            ],
            "stateMutability": "view",
            "type": "function"
        },
        {
            "inputs": [
                {
                    "internalType": "bytes32",
                    "name": "",
                    "type": "bytes32"
                }
            ],
            "name": "productMap",
            "outputs": [
                {
                    "internalType": "uint256",
                    "name": "",
                    "type": "uint256"
                }
            ],
            "stateMutability": "view",
            "type": "function"
        },
        {
            "inputs": [
                {
                    "internalType": "bytes32",
                    "name": "",
                    "type": "bytes32"
                }
            ],
            "name": "productsForSale",
            "outputs": [
                {
                    "internalType": "bytes32",
                    "name": "",
                    "type": "bytes32"
                }
            ],
            "stateMutability": "view",
            "type": "function"
        },
        {
            "inputs": [
                {
                    "internalType": "bytes32",
                    "name": "",
                    "type": "bytes32"
                }
            ],
            "name": "productsManufactured",
            "outputs": [
                {
                    "internalType": "bytes32",
                    "name": "",
                    "type": "bytes32"
                }
            ],
            "stateMutability": "view",
            "type": "function"
        },
        {
            "inputs": [
                {
                    "internalType": "bytes32",
                    "name": "",
                    "type": "bytes32"
                }
            ],
            "name": "productsSold",
            "outputs": [
                {
                    "internalType": "bytes32",
                    "name": "",
                    "type": "bytes32"
                }
            ],
            "stateMutability": "view",
            "type": "function"
        },
        {
            "inputs": [
                {
                    "internalType": "bytes32",
                    "name": "",
                    "type": "bytes32"
                },
                {
                    "internalType": "uint256",
                    "name": "",
                    "type": "uint256"
                }
            ],
            "name": "productsWithConsumer",
            "outputs": [
                {
                    "internalType": "bytes32",
                    "name": "",
                    "type": "bytes32"
                }
            ],
            "stateMutability": "view",
            "type": "function"
        },
        {
            "inputs": [
                {
                    "internalType": "bytes32",
                    "name": "",
                    "type": "bytes32"
                },
                {
                    "internalType": "uint256",
                    "name": "",
                    "type": "uint256"
                }
            ],
            "name": "productsWithSeller",
            "outputs": [
                {
                    "internalType": "bytes32",
                    "name": "",
                    "type": "bytes32"
                }
            ],
            "stateMutability": "view",
            "type": "function"
        },
        {
            "inputs": [
                {
                    "internalType": "bytes32",
                    "name": "_sellerCode",
                    "type": "bytes32"
                }
            ],
            "name": "queryProductsList",
            "outputs": [
                {
                    "internalType": "uint256[]",
                    "name": "",
                    "type": "uint256[]"
                },
                {
                    "internalType": "bytes32[]",
                    "name": "",
                    "type": "bytes32[]"
                },
                {
                    "internalType": "bytes32[]",
                    "name": "",
                    "type": "bytes32[]"
                },
                {
                    "internalType": "bytes32[]",
                    "name": "",
                    "type": "bytes32[]"
                },
                {
                    "internalType": "uint256[]",
                    "name": "",
                    "type": "uint256[]"
                },
                {
                    "internalType": "bytes32[]",
                    "name": "",
                    "type": "bytes32[]"
                }
            ],
            "stateMutability": "view",
            "type": "function"
        },
        {
            "inputs": [
                {
                    "internalType": "bytes32",
                    "name": "_manufacturerCode",
                    "type": "bytes32"
                }
            ],
            "name": "querySellersList",
            "outputs": [
                {
                    "internalType": "uint256[]",
                    "name": "",
                    "type": "uint256[]"
                },
                {
                    "internalType": "bytes32[]",
                    "name": "",
                    "type": "bytes32[]"
                },
                {
                    "internalType": "bytes32[]",
                    "name": "",
                    "type": "bytes32[]"
                },
                {
                    "internalType": "bytes32[]",
                    "name": "",
                    "type": "bytes32[]"
                },
                {
                    "internalType": "uint256[]",
                    "name": "",
                    "type": "uint256[]"
                },
                {
                    "internalType": "bytes32[]",
                    "name": "",
                    "type": "bytes32[]"
                },
                {
                    "internalType": "bytes32[]",
                    "name": "",
                    "type": "bytes32[]"
                }
            ],
            "stateMutability": "view",
            "type": "function"
        },
        {
            "inputs": [
                {
                    "internalType": "uint256",
                    "name": "",
                    "type": "uint256"
                }
            ],
            "name": "sellers",
            "outputs": [
                {
                    "internalType": "uint256",
                    "name": "sellerId",
                    "type": "uint256"
                },
                {
                    "internalType": "bytes32",
                    "name": "sellerName",
                    "type": "bytes32"
                },
                {
                    "internalType": "bytes32",
                    "name": "sellerBrand",
                    "type": "bytes32"
                },
                {
                    "internalType": "bytes32",
                    "name": "sellerCode",
                    "type": "bytes32"
                },
                {
                    "internalType": "uint256",
                    "name": "sellerNum",
                    "type": "uint256"
                },
                {
                    "internalType": "bytes32",
                    "name": "sellerManager",
                    "type": "bytes32"
                },
                {
                    "internalType": "bytes32",
                    "name": "sellerAddress",
                    "type": "bytes32"
                }
            ],
            "stateMutability": "view",
            "type": "function"
        },
        {
            "inputs": [
                {
                    "internalType": "bytes32",
                    "name": "",
                    "type": "bytes32"
                },
                {
                    "internalType": "uint256",
                    "name": "",
                    "type": "uint256"
                }
            ],
            "name": "sellersWithManufacturer",
            "outputs": [
                {
                    "internalType": "bytes32",
                    "name": "",
                    "type": "bytes32"
                }
            ],
            "stateMutability": "view",
            "type": "function"
        },
        {
            "inputs": [
                {
                    "internalType": "bytes32",
                    "name": "_productSN",
                    "type": "bytes32"
                },
                {
                    "internalType": "bytes32",
                    "name": "_consumerCode",
                    "type": "bytes32"
                }
            ],
            "name": "verifyProduct",
            "outputs": [
                {
                    "internalType": "bool",
                    "name": "",
                    "type": "bool"
                }
            ],
            "stateMutability": "view",
            "type": "function"
        },
        {
            "inputs": [],
            "name": "viewProductItems",
            "outputs": [
                {
                    "internalType": "uint256[]",
                    "name": "",
                    "type": "uint256[]"
                },
                {
                    "internalType": "bytes32[]",
                    "name": "",
                    "type": "bytes32[]"
                },
                {
                    "internalType": "bytes32[]",
                    "name": "",
                    "type": "bytes32[]"
                },
                {
                    "internalType": "bytes32[]",
                    "name": "",
                    "type": "bytes32[]"
                },
                {
                    "internalType": "uint256[]",
                    "name": "",
                    "type": "uint256[]"
                },
                {
                    "internalType": "bytes32[]",
                    "name": "",
                    "type": "bytes32[]"
                }
            ],
            "stateMutability": "view",
            "type": "function"
        },
        {
            "inputs": [],
            "name": "viewSellers",
            "outputs": [
                {
                    "internalType": "uint256[]",
                    "name": "",
                    "type": "uint256[]"
                },
                {
                    "internalType": "bytes32[]",
                    "name": "",
                    "type": "bytes32[]"
                },
                {
                    "internalType": "bytes32[]",
                    "name": "",
                    "type": "bytes32[]"
                },
                {
                    "internalType": "bytes32[]",
                    "name": "",
                    "type": "bytes32[]"
                },
                {
                    "internalType": "uint256[]",
                    "name": "",
                    "type": "uint256[]"
                },
                {
                    "internalType": "bytes32[]",
                    "name": "",
                    "type": "bytes32[]"
                },
                {
                    "internalType": "bytes32[]",
                    "name": "",
                    "type": "bytes32[]"
                }
            ],
            "stateMutability": "view",
            "type": "function"
        }
    ]; // Replace with your contract ABI
    const provider = new ethers.providers.Web3Provider(window.ethereum);
    const signer = provider.getSigner();
    const contract = new ethers.Contract(contractAddress, contractABI, signer);

    // Get data from the contract
    const dataElement = document.getElementById('data');
    const data = await contract.data();
    dataElement.textContent = data.toString();
});

async function setData() {
    const dataInput = document.getElementById('dataInput').value;
    await contract.setData(dataInput);
    location.reload(); // Refresh the page to update the displayed data
}