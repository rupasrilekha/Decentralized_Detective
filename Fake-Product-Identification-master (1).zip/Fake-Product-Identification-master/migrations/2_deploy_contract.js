var product=artifacts.require('product');

module.exports=function(deployer) {
    deployer.deploy(product); 
}